export interface Commit {
  id: string
  hash: string
  message: string
  date: string
  branch: string
  type: 'normal' | 'milestone' | 'merge'
  tag?: string
  project?: {
    title: string
    description: string
    tech: string[]
    link?: string
    github?: string
    additions: number
    deletions: number
  }
}

export interface Branch {
  name: string
  color: string
  skills: string[]
}

export const branches: Branch[] = [
  { name: 'main', color: '#C9D1D9', skills: [] },
  { name: 'frontend', color: '#58A6FF', skills: ['React', 'Next.js', 'Three.js', 'TypeScript', 'Tailwind CSS'] },
  { name: 'backend', color: '#F05032', skills: ['Node.js', 'Python', 'PostgreSQL', 'Redis', 'GraphQL'] },
  { name: 'design', color: '#D2A8FF', skills: ['Figma', 'UI/UX', 'Animation', 'Design Systems'] },
  { name: 'ai-ml', color: '#7EE787', skills: ['TensorFlow', 'LLMs', 'Data Science', 'PyTorch'] },
]

export const commits: Commit[] = [
  {
    id: 'c1',
    hash: 'a3f52c9',
    message: 'Initial commit - Hello, World!',
    date: '2020-03-15',
    branch: 'main',
    type: 'milestone',
    tag: 'v0.1',
    project: {
      title: 'First Steps',
      description: 'My first lines of code. A simple HTML page that changed everything.',
      tech: ['HTML', 'CSS', 'JavaScript'],
      additions: 47,
      deletions: 0,
    },
  },
  {
    id: 'c2',
    hash: 'b7e41d2',
    message: 'feat: learn responsive design fundamentals',
    date: '2020-06-22',
    branch: 'frontend',
    type: 'normal',
    project: {
      title: 'Responsive Portfolio v1',
      description: 'First portfolio site with CSS Grid and media queries.',
      tech: ['HTML', 'CSS', 'Sass'],
      additions: 312,
      deletions: 45,
    },
  },
  {
    id: 'c3',
    hash: 'c9d83f1',
    message: 'feat: build first React application',
    date: '2020-11-08',
    branch: 'frontend',
    type: 'milestone',
    tag: 'v0.5',
    project: {
      title: 'Task Manager App',
      description: 'A full CRUD task manager built with React and local storage.',
      tech: ['React', 'JavaScript', 'CSS Modules'],
      link: 'https://example.com',
      additions: 1247,
      deletions: 0,
    },
  },
  {
    id: 'c4',
    hash: 'd2f94a7',
    message: 'feat: setup Node.js backend with Express',
    date: '2021-02-14',
    branch: 'backend',
    type: 'normal',
    project: {
      title: 'REST API Server',
      description: 'Built a REST API with authentication, rate limiting, and PostgreSQL.',
      tech: ['Node.js', 'Express', 'PostgreSQL'],
      github: 'https://github.com',
      additions: 892,
      deletions: 23,
    },
  },
  {
    id: 'c5',
    hash: 'e5a12b3',
    message: 'feat: first freelance project delivered',
    date: '2021-05-30',
    branch: 'main',
    type: 'milestone',
    tag: 'v1.0',
    project: {
      title: 'E-Commerce Platform',
      description: 'Full-stack e-commerce site for a local business. My first paid project.',
      tech: ['React', 'Node.js', 'Stripe', 'MongoDB'],
      additions: 3456,
      deletions: 287,
    },
  },
  {
    id: 'c6',
    hash: 'f8c37d5',
    message: 'feat: dive into UI/UX design principles',
    date: '2021-08-12',
    branch: 'design',
    type: 'normal',
    project: {
      title: 'Design System',
      description: 'Created a comprehensive design system with Figma components and tokens.',
      tech: ['Figma', 'Design Tokens', 'Storybook'],
      additions: 567,
      deletions: 134,
    },
  },
  {
    id: 'c7',
    hash: 'a1b2c3d',
    message: 'feat: master TypeScript and Next.js',
    date: '2022-01-20',
    branch: 'frontend',
    type: 'milestone',
    tag: 'v1.5',
    project: {
      title: 'SaaS Dashboard',
      description: 'Analytics dashboard with real-time data, charts, and team management.',
      tech: ['Next.js', 'TypeScript', 'Tailwind', 'Prisma'],
      link: 'https://example.com',
      additions: 5678,
      deletions: 1234,
    },
  },
  {
    id: 'c8',
    hash: 'e4f5a6b',
    message: 'merge: full-stack collaboration on open source',
    date: '2022-05-15',
    branch: 'main',
    type: 'merge',
    project: {
      title: 'OSS Contribution',
      description: 'Major contribution to an open-source UI library. 50+ PRs merged.',
      tech: ['React', 'TypeScript', 'Testing Library'],
      github: 'https://github.com',
      additions: 2341,
      deletions: 876,
    },
  },
  {
    id: 'c9',
    hash: 'g7h8i9j',
    message: 'feat: explore machine learning with Python',
    date: '2022-09-03',
    branch: 'ai-ml',
    type: 'normal',
    project: {
      title: 'Image Classifier',
      description: 'CNN-based image classification model trained on custom dataset.',
      tech: ['Python', 'TensorFlow', 'NumPy'],
      github: 'https://github.com',
      additions: 1456,
      deletions: 89,
    },
  },
  {
    id: 'c10',
    hash: 'k1l2m3n',
    message: 'feat: build real-time collaboration tool',
    date: '2023-01-18',
    branch: 'backend',
    type: 'normal',
    project: {
      title: 'Collab Editor',
      description: 'Real-time collaborative document editor with WebSocket sync.',
      tech: ['Node.js', 'WebSocket', 'Redis', 'React'],
      link: 'https://example.com',
      additions: 4123,
      deletions: 567,
    },
  },
  {
    id: 'c11',
    hash: 'o4p5q6r',
    message: 'feat: create interactive 3D web experiences',
    date: '2023-05-22',
    branch: 'frontend',
    type: 'milestone',
    tag: 'v2.0',
    project: {
      title: '3D Product Configurator',
      description: 'WebGL product customizer with real-time rendering and AR preview.',
      tech: ['Three.js', 'React Three Fiber', 'WebXR'],
      link: 'https://example.com',
      additions: 3789,
      deletions: 234,
    },
  },
  {
    id: 'c12',
    hash: 's7t8u9v',
    message: 'feat: integrate LLMs into production apps',
    date: '2023-09-10',
    branch: 'ai-ml',
    type: 'normal',
    project: {
      title: 'AI Writing Assistant',
      description: 'AI-powered writing tool with streaming responses and context awareness.',
      tech: ['Next.js', 'OpenAI', 'Vercel AI SDK', 'PostgreSQL'],
      link: 'https://example.com',
      additions: 2567,
      deletions: 345,
    },
  },
  {
    id: 'c13',
    hash: 'w1x2y3z',
    message: 'feat: design system overhaul with motion',
    date: '2024-01-05',
    branch: 'design',
    type: 'normal',
    project: {
      title: 'Motion Design System',
      description: 'Comprehensive design system with animation primitives and micro-interactions.',
      tech: ['Framer Motion', 'Figma', 'Storybook', 'Tailwind'],
      additions: 1890,
      deletions: 678,
    },
  },
  {
    id: 'c14',
    hash: 'a4b5c6d',
    message: 'merge: lead team on enterprise platform',
    date: '2024-06-20',
    branch: 'main',
    type: 'merge',
    project: {
      title: 'Enterprise Platform',
      description: 'Led development of multi-tenant SaaS platform serving 10K+ users.',
      tech: ['Next.js', 'TypeScript', 'PostgreSQL', 'AWS'],
      additions: 12456,
      deletions: 3456,
    },
  },
  {
    id: 'c15',
    hash: 'e7f8g9h',
    message: 'feat: build AI-powered developer tools',
    date: '2024-11-15',
    branch: 'ai-ml',
    type: 'milestone',
    tag: 'v3.0',
    project: {
      title: 'AI Code Review Bot',
      description: 'Automated code review tool using LLMs for quality and security analysis.',
      tech: ['Python', 'LangChain', 'FastAPI', 'React'],
      github: 'https://github.com',
      additions: 5678,
      deletions: 1234,
    },
  },
  {
    id: 'c16',
    hash: 'i1j2k3l',
    message: 'feat: this portfolio you\'re viewing right now',
    date: '2025-02-01',
    branch: 'main',
    type: 'milestone',
    tag: 'HEAD',
    project: {
      title: 'Interactive 3D Portfolio',
      description: 'An immersive git-themed portfolio built with React Three Fiber.',
      tech: ['Next.js', 'Three.js', 'R3F', 'TypeScript'],
      link: '#',
      additions: 4321,
      deletions: 0,
    },
  },
]

// Simulated contribution data (52 weeks x 7 days)
export function generateContributionData(): number[][] {
  const data: number[][] = []
  for (let week = 0; week < 52; week++) {
    const weekData: number[] = []
    for (let day = 0; day < 7; day++) {
      const base = Math.sin(week / 8) * 3 + 2
      const noise = Math.random() * 4
      weekData.push(Math.max(0, Math.floor(base + noise)))
    }
    data.push(weekData)
  }
  return data
}

// Stats
export const stats = {
  totalCommits: 2847,
  currentStreak: 47,
  longestStreak: 142,
  languages: [
    { name: 'TypeScript', percentage: 38, color: '#3178C6' },
    { name: 'Python', percentage: 22, color: '#3572A5' },
    { name: 'JavaScript', percentage: 18, color: '#F7DF1E' },
    { name: 'CSS', percentage: 12, color: '#58A6FF' },
    { name: 'Other', percentage: 10, color: '#8B949E' },
  ],
  starsEarned: 342,
  prsOpened: 567,
  prsMerged: 523,
}

export const contactLinks = [
  { file: 'email.txt', command: 'cat email.txt', content: 'contact@developer.dev', href: 'mailto:contact@developer.dev' },
  { file: 'linkedin.md', command: 'cat linkedin.md', content: 'linkedin.com/in/developer', href: 'https://linkedin.com' },
  { file: 'github.sh', command: './github.sh', content: 'github.com/developer', href: 'https://github.com' },
  { file: 'resume.pdf', command: 'open resume.pdf', content: 'Opening resume.pdf...', href: '#' },
]
