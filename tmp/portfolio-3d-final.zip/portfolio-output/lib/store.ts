import { create } from 'zustand'

interface PortfolioState {
  // Scroll progress 0-1
  scrollProgress: number
  setScrollProgress: (progress: number) => void

  // Active commit index
  activeCommitIndex: number
  setActiveCommitIndex: (index: number) => void

  // Active branch (null = main timeline)
  activeBranch: string | null
  setActiveBranch: (branch: string | null) => void

  // Hovered commit
  hoveredCommit: string | null
  setHoveredCommit: (id: string | null) => void

  // Current section
  activeSection: 'hero' | 'timeline' | 'branches' | 'terrain' | 'stats' | 'contact'
  setActiveSection: (section: PortfolioState['activeSection']) => void

  // Loading
  isLoaded: boolean
  setIsLoaded: (loaded: boolean) => void

  // Sound toggle
  soundEnabled: boolean
  toggleSound: () => void
}

export const usePortfolioStore = create<PortfolioState>((set) => ({
  scrollProgress: 0,
  setScrollProgress: (progress) => set({ scrollProgress: progress }),

  activeCommitIndex: 0,
  setActiveCommitIndex: (index) => set({ activeCommitIndex: index }),

  activeBranch: null,
  setActiveBranch: (branch) => set({ activeBranch: branch }),

  hoveredCommit: null,
  setHoveredCommit: (id) => set({ hoveredCommit: id }),

  activeSection: 'hero',
  setActiveSection: (section) => set({ activeSection: section }),

  isLoaded: false,
  setIsLoaded: (loaded) => set({ isLoaded: loaded }),

  soundEnabled: false,
  toggleSound: () => set((state) => ({ soundEnabled: !state.soundEnabled })),
}))
