'use client'

import { useEffect, useState, useCallback, useRef } from 'react'
import dynamic from 'next/dynamic'
import { usePortfolioStore } from '@/lib/store'
import { commits } from '@/lib/portfolio-data'
import { LoadingScreen }     from '@/components/ui/loading-screen'
import { HeroOverlay }       from '@/components/ui/hero-overlay'
import { CommitDetailPanel } from '@/components/ui/commit-detail-panel'
import { BranchNavigator }   from '@/components/ui/branch-navigator'
import { StatsOverlay }      from '@/components/ui/stats-overlay'
import { ContactTerminal }   from '@/components/ui/contact-terminal'
import { ScrollMinimap }     from '@/components/ui/scroll-minimap'

const Scene3D = dynamic(
  () => import('@/components/three/scene-canvas').then(m => m.SceneCanvas),
  {
    ssr: false,
    loading: () => (
      <div className="w-full h-screen" style={{ background: '#0D1117' }}>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-mono text-xs animate-pulse" style={{ color: '#555f6a' }}>
            initializing renderer…
          </span>
        </div>
      </div>
    ),
  }
)

export default function PortfolioPage() {
  const [loading,     setLoading]     = useState(true)
  const [showContent, setShowContent] = useState(false)

  const scrollProgress     = usePortfolioStore(s => s.scrollProgress)
  const setScrollProgress  = usePortfolioStore(s => s.setScrollProgress)
  const setActiveCommitIndex = usePortfolioStore(s => s.setActiveCommitIndex)

  const handleLoadComplete = useCallback(() => {
    setLoading(false)
    setTimeout(() => setShowContent(true), 80)
  }, [])

  useEffect(() => {
    const onScroll = () => {
      const total    = document.documentElement.scrollHeight - window.innerHeight
      const progress = Math.min(1, Math.max(0, window.scrollY / total))
      setScrollProgress(progress)
      setActiveCommitIndex(
        Math.min(commits.length - 1, Math.floor(progress * commits.length))
      )
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [setScrollProgress, setActiveCommitIndex])

  return (
    <main>
      {loading && <LoadingScreen onComplete={handleLoadComplete} />}

      {/* Tall scroll container — drives the entire experience */}
      <div style={{ height: '900vh' }} />

      {/* Fixed 3D canvas */}
      <div className="fixed inset-0 z-0">
        <Scene3D />
      </div>

      {showContent && (
        <>
          <HeroOverlay visible={scrollProgress < 0.07} />
          <CommitDetailPanel />
          <BranchNavigator />
          <StatsOverlay />
          <ContactTerminal />
          <ScrollMinimap />
          <TopBar progress={scrollProgress} />
        </>
      )}
    </main>
  )
}

/* ── Minimal sticky top bar ── */
function TopBar({ progress }: { progress: number }) {
  if (progress <= 0.02) return null

  const commit = commits[Math.min(commits.length - 1, Math.floor(progress * commits.length))]

  return (
    <header
      className="fixed top-0 left-0 right-0 z-30 flex items-center justify-between px-6 py-3"
      style={{ background: 'linear-gradient(to bottom, rgba(13,17,23,0.85) 0%, transparent 100%)' }}
    >
      {/* Left: git log command */}
      <div className="flex items-center gap-2.5">
        <div
          className="w-1.5 h-1.5 rounded-full"
          style={{ background: '#7EE787', boxShadow: '0 0 6px #7EE787', animation: 'glow-pulse 2s ease-in-out infinite' }}
        />
        <span className="text-[11px] font-mono" style={{ color: '#555f6a' }}>
          git log --oneline --graph
        </span>
      </div>

      {/* Centre: progress bar */}
      <div className="flex-1 max-w-[220px] mx-6">
        <div className="h-[1px] w-full rounded-full overflow-hidden" style={{ background: '#21262D' }}>
          <div
            className="h-full rounded-full"
            style={{
              width: `${progress * 100}%`,
              background: 'linear-gradient(90deg, #58A6FF, #7EE787)',
              boxShadow: '0 0 6px #58A6FF',
              transition: 'width 0.15s linear',
            }}
          />
        </div>
      </div>

      {/* Right: current date */}
      <span className="text-[11px] font-mono" style={{ color: '#555f6a' }}>
        {commit?.date ?? ''}
      </span>
    </header>
  )
}
