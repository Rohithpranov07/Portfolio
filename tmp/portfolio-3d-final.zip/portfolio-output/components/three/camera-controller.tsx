'use client'

import { useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'

interface CameraControllerProps {
  scrollProgress: number
  totalLength: number
}

export function CameraController({ scrollProgress, totalLength }: CameraControllerProps) {
  const { camera } = useThree()
  const targetPos  = useRef(new THREE.Vector3(0, 2, 10))
  const targetLook = useRef(new THREE.Vector3(0, 0, 0))
  const currentLook = useRef(new THREE.Vector3(0, 0, 0))

  useFrame((state) => {
    const t     = state.clock.elapsedTime
    const mouse = state.pointer

    // Base Z follows scroll
    const z = -scrollProgress * totalLength

    // Subtle side-drift tied to mouse + slow sine
    const xDrift = mouse.x * 0.6 + Math.sin(t * 0.18) * 0.4
    const yDrift = mouse.y * 0.25 + Math.sin(t * 0.22) * 0.15

    // Camera height eases up as you scroll deeper
    const yOffset = 2.2 + scrollProgress * 1.2 + yDrift

    targetPos.current.set(xDrift, yOffset, z + 8)

    // Look slightly ahead of travel direction
    targetLook.current.set(
      xDrift * 0.3,
      yOffset - 1.0,
      z - 6
    )

    // Smooth lerp for buttery camera movement
    camera.position.lerp(targetPos.current, 0.055)
    currentLook.current.lerp(targetLook.current, 0.055)
    camera.lookAt(currentLook.current)
  })

  return null
}
