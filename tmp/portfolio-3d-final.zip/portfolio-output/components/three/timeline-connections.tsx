'use client'

import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Line } from '@react-three/drei'
import * as THREE from 'three'
import type { Commit } from '@/lib/portfolio-data'
import { branches } from '@/lib/portfolio-data'

interface TimelineConnectionsProps {
  commits: Commit[]
  getCommitPosition: (index: number) => [number, number, number]
  activeIndex: number
}

export function TimelineConnections({ commits, getCommitPosition, activeIndex }: TimelineConnectionsProps) {
  const particlesRef = useRef<THREE.Points>(null!)
  const PARTICLES_PER_CURVE = 40

  const { curves, lineColors, mergeSet } = useMemo(() => {
    const curvesArr: THREE.CatmullRomCurve3[] = []
    const colorsArr: string[] = []
    const merges = new Set<number>()

    for (let i = 0; i < commits.length - 1; i++) {
      const s  = getCommitPosition(i)
      const e  = getCommitPosition(i + 1)
      // A control point that arcs inward/outward based on branch change
      const sameBranch = commits[i].branch === commits[i + 1].branch
      const ctrlY = (s[1] + e[1]) / 2 + (sameBranch ? 0.25 : 1.1)
      const ctrlX = (s[0] + e[0]) / 2 + (sameBranch ? 0 : -(e[0] - s[0]) * 0.3)

      curvesArr.push(
        new THREE.CatmullRomCurve3([
          new THREE.Vector3(...s),
          new THREE.Vector3(ctrlX, ctrlY, (s[2] + e[2]) / 2),
          new THREE.Vector3(...e),
        ])
      )

      const b = branches.find(b => b.name === commits[i + 1].branch)
      colorsArr.push(b?.color ?? '#C9D1D9')
      if (commits[i + 1].type === 'merge') merges.add(i)
    }
    return { curves: curvesArr, lineColors: colorsArr, mergeSet: merges }
  }, [commits, getCommitPosition])

  const lineData = useMemo(() =>
    curves.map((c, i) => ({ points: c.getPoints(50) as THREE.Vector3[], color: lineColors[i] }))
  , [curves, lineColors])

  // Particle flow positions + per-particle speed
  const { initPos, colors: pColors, speeds } = useMemo(() => {
    const total = curves.length * PARTICLES_PER_CURVE
    const pos   = new Float32Array(total * 3)
    const cols  = new Float32Array(total * 3)
    const spds  = new Float32Array(total)

    curves.forEach((curve, ci) => {
      const col = new THREE.Color(lineColors[ci])
      for (let i = 0; i < PARTICLES_PER_CURVE; i++) {
        const idx = ci * PARTICLES_PER_CURVE + i
        const t = i / PARTICLES_PER_CURVE
        const pt = curve.getPointAt(t)
        pos[idx * 3]     = pt.x
        pos[idx * 3 + 1] = pt.y
        pos[idx * 3 + 2] = pt.z
        cols[idx * 3]    = col.r
        cols[idx * 3 + 1] = col.g
        cols[idx * 3 + 2] = col.b
        spds[idx] = 0.06 + Math.random() * 0.12
      }
    })
    return { initPos: pos, colors: cols, speeds: spds }
  }, [curves, lineColors])

  useFrame(({ clock }) => {
    if (!particlesRef.current) return
    const posAttr = particlesRef.current.geometry.getAttribute('position')
    const t = clock.elapsedTime

    curves.forEach((curve, ci) => {
      for (let i = 0; i < PARTICLES_PER_CURVE; i++) {
        const idx = ci * PARTICLES_PER_CURVE + i
        const progress = ((i / PARTICLES_PER_CURVE + t * speeds[idx]) % 1)
        const pt = curve.getPointAt(progress)
        posAttr.setXYZ(idx, pt.x, pt.y, pt.z)
      }
    })
    posAttr.needsUpdate = true
  })

  return (
    <group>
      {/* Main lines — glow version (wide, dim) then sharp version */}
      {lineData.map((data, i) => {
        const passed  = i < activeIndex
        const current = i === activeIndex
        const opacity = current ? 1 : passed ? 0.55 : 0.15
        const isMerge = mergeSet.has(i)

        return (
          <group key={i}>
            {/* Wide glow underline */}
            <Line
              points={data.points}
              color={data.color}
              lineWidth={current ? 7 : isMerge ? 5 : 3}
              transparent
              opacity={opacity * 0.22}
              depthWrite={false}
            />
            {/* Crisp main line */}
            <Line
              points={data.points}
              color={data.color}
              lineWidth={current ? 2.2 : 1.4}
              transparent
              opacity={opacity}
              dashed={!passed && !current}
              dashScale={30}
              dashSize={0.6}
              gapSize={0.4}
            />
          </group>
        )
      })}

      {/* Flowing particles */}
      <points ref={particlesRef}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[initPos, 3]} />
          <bufferAttribute attach="attributes-color"    args={[pColors, 3]} />
        </bufferGeometry>
        <pointsMaterial
          size={0.055}
          vertexColors
          transparent
          opacity={0.85}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
          sizeAttenuation
        />
      </points>
    </group>
  )
}
