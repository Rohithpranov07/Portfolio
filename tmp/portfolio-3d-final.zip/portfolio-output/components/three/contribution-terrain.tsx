'use client'

import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Text } from '@react-three/drei'
import * as THREE from 'three'
import { generateContributionData } from '@/lib/portfolio-data'

interface ContributionTerrainProps {
  position: [number, number, number]
  opacity: number
}

export function ContributionTerrain({ position, opacity }: ContributionTerrainProps) {
  const groupRef = useRef<THREE.Group>(null!)

  const { meshData } = useMemo(() => {
    const data = generateContributionData()
    const meshData: { pos: [number,number,number]; h: number; color: string }[] = []
    const cs = 0.11
    const gap = 0.015

    for (let week = 0; week < data.length; week++) {
      for (let day = 0; day < data[week].length; day++) {
        const val = data[week][day]
        if (val === 0) continue

        const h = val * 0.085 + 0.025
        const intensity = val / 9
        const stops = ['#0e4429','#006d32','#26a641','#39d353','#56d466']
        const ci = Math.min(Math.floor(intensity * stops.length), stops.length - 1)

        meshData.push({
          pos: [(week - 26) * (cs + gap), h / 2, (day - 3) * (cs + gap)],
          h,
          color: stops[ci],
        })
      }
    }
    return { meshData }
  }, [])

  useFrame(({ clock }) => {
    if (!groupRef.current) return
    // Gentle hover + slow Y rotation
    groupRef.current.position.y = Math.sin(clock.elapsedTime * 0.4) * 0.08
    groupRef.current.rotation.y = Math.sin(clock.elapsedTime * 0.15) * 0.06
  })

  return (
    <group ref={groupRef} position={position}>
      {/* Label above */}
      <Text
        position={[0, 2.2, 0]}
        fontSize={0.35}
        color="#7EE787"
        anchorX="center"
        anchorY="middle"
        letterSpacing={0.08}
      >
        {'< contribution graph />'}
      </Text>

      {/* Glowing base plane */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.05, 0]}>
        <planeGeometry args={[6.5, 1.2]} />
        <meshBasicMaterial color="#26a641" transparent opacity={opacity * 0.06} />
      </mesh>

      {meshData.map((m, i) => (
        <mesh key={i} position={m.pos}>
          <boxGeometry args={[0.10, m.h, 0.10]} />
          <meshStandardMaterial
            color={m.color}
            emissive={m.color}
            emissiveIntensity={0.55}
            metalness={0.3}
            roughness={0.4}
            transparent
            opacity={opacity}
          />
        </mesh>
      ))}
    </group>
  )
}
