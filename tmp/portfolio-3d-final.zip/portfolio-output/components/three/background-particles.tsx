'use client'

import { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'

export function BackgroundParticles({ count = 500 }: { count?: number }) {
  const ref = useRef<THREE.Points>(null!)

  // Multi-colored cloud spread over a long corridor matching the timeline
  const { positions, colors } = useMemo(() => {
    const pos  = new Float32Array(count * 3)
    const cols = new Float32Array(count * 3)

    const palette = [
      new THREE.Color('#58A6FF'),
      new THREE.Color('#7EE787'),
      new THREE.Color('#F05032'),
      new THREE.Color('#D2A8FF'),
      new THREE.Color('#c9d1d9'),
    ]

    for (let i = 0; i < count; i++) {
      pos[i * 3]     = (Math.random() - 0.5) * 28
      pos[i * 3 + 1] = (Math.random() - 0.5) * 20
      pos[i * 3 + 2] = Math.random() * -240  // spread along entire depth
      const c = palette[Math.floor(Math.random() * palette.length)]
      cols[i * 3]     = c.r
      cols[i * 3 + 1] = c.g
      cols[i * 3 + 2] = c.b
    }
    return { positions: pos, colors: cols }
  }, [count])

  useFrame(({ clock }) => {
    if (!ref.current) return
    const t = clock.elapsedTime
    // Slow rotation for parallax depth feeling
    ref.current.rotation.y = t * 0.006
    ref.current.rotation.x = Math.sin(t * 0.09) * 0.018
  })

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-color"    args={[colors,    3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.045}
        vertexColors
        transparent
        opacity={0.55}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
        sizeAttenuation
      />
    </points>
  )
}
