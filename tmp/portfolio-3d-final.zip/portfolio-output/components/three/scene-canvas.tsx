'use client'

import { Canvas } from '@react-three/fiber'
import { Suspense } from 'react'
import { PortfolioScene } from './portfolio-scene'

export function SceneCanvas() {
  return (
    <div className="w-full h-screen">
      <Canvas
        camera={{ position: [0, 2, 10], fov: 62, near: 0.1, far: 300 }}
        gl={{
          antialias: true,
          alpha: false,
          powerPreference: 'high-performance',
          toneMapping: 4,        // ACESFilmicToneMapping
          toneMappingExposure: 1.1,
        }}
        style={{ background: '#0D1117' }}
        dpr={[1, 2]}
      >
        <Suspense fallback={null}>
          <PortfolioScene />
        </Suspense>
      </Canvas>
    </div>
  )
}
