'use client'

import { useRef, useState, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html } from '@react-three/drei'
import * as THREE from 'three'
import type { Commit } from '@/lib/portfolio-data'
import { branches } from '@/lib/portfolio-data'
import { usePortfolioStore } from '@/lib/store'

interface CommitNodeProps {
  commit: Commit
  position: [number, number, number]
  index: number
  isActive: boolean
  opacity: number
}

// Per-frame scratch objects to avoid GC pressure
const _scale = new THREE.Vector3()

export function CommitNode({ commit, position, index, isActive, opacity }: CommitNodeProps) {
  const coreRef  = useRef<THREE.Mesh>(null!)
  const glowRef  = useRef<THREE.Mesh>(null!)
  const ringRef  = useRef<THREE.Mesh>(null!)
  const orbitRef = useRef<THREE.Group>(null!)
  const [hovered, setHovered] = useState(false)
  const setHoveredCommit = usePortfolioStore((s) => s.setHoveredCommit)

  const color = useMemo(() => {
    const b = branches.find(b => b.name === commit.branch)
    return b?.color ?? '#C9D1D9'
  }, [commit.branch])

  // Radius sizes
  const r = commit.type === 'milestone' ? 0.38 : commit.type === 'merge' ? 0.30 : 0.22

  // 12 small satellite particles orbiting the node
  const orbitParticles = useMemo(() => {
    const count = commit.type === 'milestone' ? 12 : 6
    return Array.from({ length: count }, (_, i) => ({
      angle: (i / count) * Math.PI * 2,
      radius: r * 2.8 + Math.random() * r,
      speed:  0.4 + Math.random() * 0.5,
      size:   0.025 + Math.random() * 0.03,
      yPhase: Math.random() * Math.PI * 2,
    }))
  }, [commit.type, r])

  useFrame(({ clock }) => {
    const t = clock.elapsedTime
    const hover = hovered ? 1 : 0

    // Core: pulse + spin + hover scale
    if (coreRef.current) {
      const pulse = isActive ? 1 + Math.sin(t * 2.8) * 0.12 : 1
      const hoverS = 1 + hover * 0.35
      _scale.setScalar(r * pulse * hoverS)
      coreRef.current.scale.lerp(_scale, 0.15)
      // Milestones and merges spin
      if (commit.type !== 'normal') coreRef.current.rotation.y = t * 0.6
      if (commit.type === 'merge')  coreRef.current.rotation.x = t * 0.4
    }

    // Glow halo: larger, breathing
    if (glowRef.current) {
      const g = (isActive ? 2.6 : 1.8) + Math.sin(t * 1.5) * 0.2 + hover * 0.8
      glowRef.current.scale.setScalar(g)
      ;(glowRef.current.material as THREE.MeshBasicMaterial).opacity =
        opacity * (isActive ? 0.18 : 0.06 + hover * 0.1)
    }

    // Equatorial ring for active / hovered
    if (ringRef.current) {
      ringRef.current.visible = isActive || hovered
      ringRef.current.rotation.y = t * 1.1
      ringRef.current.rotation.x = Math.sin(t * 0.7) * 0.4
      ;(ringRef.current.material as THREE.MeshStandardMaterial).emissiveIntensity =
        1.5 + Math.sin(t * 3) * 0.5
    }

    // Orbit group rotation + individual particle sine bob
    if (orbitRef.current) {
      orbitRef.current.rotation.y = t * 0.28
      orbitRef.current.children.forEach((child, i) => {
        const p = orbitParticles[i]
        child.position.y = Math.sin(t * p.speed + p.yPhase) * 0.15
        ;(child as THREE.Mesh).visible = isActive || hovered || opacity > 0.6
      })
    }
  })

  return (
    <group position={position}>
      {/* Outer glow halo */}
      <mesh ref={glowRef}>
        <sphereGeometry args={[1, 12, 12]} />
        <meshBasicMaterial
          color={color}
          transparent
          opacity={opacity * 0.06}
          depthWrite={false}
          side={THREE.BackSide}
        />
      </mesh>

      {/* Equatorial ring */}
      <mesh ref={ringRef}>
        <torusGeometry args={[r * 1.85, 0.035, 12, 48]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={1.5}
          transparent
          opacity={opacity * 0.9}
        />
      </mesh>

      {/* Orbital satellite particles */}
      <group ref={orbitRef}>
        {orbitParticles.map((p, i) => (
          <mesh
            key={i}
            position={[
              Math.cos(p.angle) * p.radius,
              0,
              Math.sin(p.angle) * p.radius,
            ]}
          >
            <sphereGeometry args={[p.size, 6, 6]} />
            <meshBasicMaterial color={color} transparent opacity={opacity * 0.7} />
          </mesh>
        ))}
      </group>

      {/* Main node geometry */}
      <mesh
        ref={coreRef}
        onPointerEnter={(e) => {
          e.stopPropagation()
          setHovered(true)
          setHoveredCommit(commit.id)
          document.body.style.cursor = 'pointer'
        }}
        onPointerLeave={() => {
          setHovered(false)
          setHoveredCommit(null)
          document.body.style.cursor = 'default'
        }}
      >
        {commit.type === 'milestone' ? (
          <octahedronGeometry args={[1, 1]} />
        ) : commit.type === 'merge' ? (
          <icosahedronGeometry args={[1, 0]} />
        ) : (
          <sphereGeometry args={[1, 32, 32]} />
        )}
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={isActive ? 1.6 : hovered ? 1.1 : 0.45}
          roughness={0.15}
          metalness={0.85}
          transparent
          opacity={opacity}
          envMapIntensity={1.5}
        />
      </mesh>

      {/* Inner bright core */}
      <mesh scale={0.55}>
        {commit.type === 'milestone' ? (
          <octahedronGeometry args={[1, 0]} />
        ) : (
          <sphereGeometry args={[1, 8, 8]} />
        )}
        <meshBasicMaterial
          color="#ffffff"
          transparent
          opacity={opacity * (isActive ? 0.55 : 0.25)}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </mesh>

      {/* Commit hash */}
      <Html
        position={[0, -r - 0.42, 0]}
        center
        distanceFactor={12}
        style={{ pointerEvents: 'none', opacity: opacity * 0.75 }}
      >
        <div style={{
          fontFamily: 'monospace',
          fontSize: '9px',
          color: color,
          letterSpacing: '0.08em',
          whiteSpace: 'nowrap',
          textShadow: `0 0 8px ${color}80`,
        }}>
          {commit.hash}
        </div>
      </Html>

      {/* Tag badge */}
      {commit.tag && (
        <Html
          position={[0, r + 0.58, 0]}
          center
          distanceFactor={12}
          style={{ pointerEvents: 'none' }}
        >
          <div style={{
            fontFamily: 'monospace',
            fontSize: '9px',
            padding: '2px 7px',
            borderRadius: '4px',
            color: commit.tag === 'HEAD' ? '#0D1117' : color,
            background: commit.tag === 'HEAD' ? '#7EE787' : `${color}22`,
            border: `1px solid ${color}60`,
            boxShadow: `0 0 12px ${color}55`,
            whiteSpace: 'nowrap',
            letterSpacing: '0.06em',
          }}>
            {commit.tag}
          </div>
        </Html>
      )}

      {/* Hover project card */}
      {hovered && commit.project && (
        <Html
          position={[0, r + 1.5, 0]}
          center
          distanceFactor={7}
          style={{ pointerEvents: 'none' }}
        >
          <div style={{
            width: '220px',
            background: 'rgba(13,17,23,0.95)',
            backdropFilter: 'blur(16px)',
            border: `1px solid ${color}35`,
            borderRadius: '10px',
            padding: '12px 14px',
            boxShadow: `0 0 32px ${color}25, 0 8px 32px rgba(0,0,0,0.6)`,
          }}>
            <div style={{ display:'flex', alignItems:'center', gap:'6px', marginBottom:'7px' }}>
              <div style={{ width:'7px',height:'7px',borderRadius:'50%',background:color,boxShadow:`0 0 8px ${color}` }} />
              <span style={{ fontFamily:'monospace',fontSize:'9px',color:color,letterSpacing:'0.08em' }}>{commit.branch}</span>
              {commit.tag && (
                <span style={{ marginLeft:'auto',fontFamily:'monospace',fontSize:'8px',padding:'1px 5px',borderRadius:'3px',background:`${color}22`,color,border:`1px solid ${color}40` }}>
                  {commit.tag}
                </span>
              )}
            </div>
            <div style={{ fontFamily:'monospace',fontSize:'11px',fontWeight:700,color,marginBottom:'5px' }}>
              {commit.project.title}
            </div>
            <div style={{ fontSize:'10px',color:'#8B949E',lineHeight:1.5,marginBottom:'8px' }}>
              {commit.project.description}
            </div>
            <div style={{ display:'flex',flexWrap:'wrap',gap:'4px',marginBottom:'8px' }}>
              {commit.project.tech.map(t => (
                <span key={t} style={{
                  fontSize:'8px',fontFamily:'monospace',padding:'2px 5px',
                  borderRadius:'3px',background:'#161B22',color:'#8B949E',border:'1px solid #30363D'
                }}>{t}</span>
              ))}
            </div>
            <div style={{ display:'flex',gap:'10px',fontFamily:'monospace',fontSize:'9px' }}>
              <span style={{ color:'#7EE787' }}>+{commit.project.additions}</span>
              <span style={{ color:'#f85149' }}>-{commit.project.deletions}</span>
            </div>
          </div>
        </Html>
      )}
    </group>
  )
}
