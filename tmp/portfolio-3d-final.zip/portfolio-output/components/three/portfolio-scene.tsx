'use client'

import { useCallback, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { commits } from '@/lib/portfolio-data'
import { usePortfolioStore } from '@/lib/store'
import { CommitNode } from './commit-node'
import { TimelineConnections } from './timeline-connections'
import { BackgroundParticles } from './background-particles'
import { CameraController } from './camera-controller'
import { ContributionTerrain } from './contribution-terrain'
import { EffectComposer, Bloom, Vignette, ChromaticAberration } from '@react-three/postprocessing'
import { BlendFunction } from 'postprocessing'
import { Stars } from '@react-three/drei'
import * as THREE from 'three'

const COMMIT_SPACING = 5.5
const TOTAL_LENGTH = commits.length * COMMIT_SPACING

const BRANCH_X: Record<string, number> = {
  main:     0,
  frontend: -3.2,
  backend:  3.2,
  design:   -6.0,
  'ai-ml':  6.0,
}

export function PortfolioScene() {
  const scrollProgress = usePortfolioStore((s) => s.scrollProgress)
  const activeCommitIndex = usePortfolioStore((s) => s.activeCommitIndex)
  const gridRef = useRef<THREE.Mesh>(null!)

  useFrame(() => {
    if (gridRef.current) {
      gridRef.current.position.z = (scrollProgress * TOTAL_LENGTH * -1) % 3
    }
  })

  const getCommitPosition = useCallback((index: number): [number, number, number] => {
    const commit = commits[index]
    const z = -index * COMMIT_SPACING
    const baseX = BRANCH_X[commit.branch] ?? 0
    const phase = Object.keys(BRANCH_X).indexOf(commit.branch) * 1.3
    const weaveX = baseX + Math.sin(index * 0.45 + phase) * 0.4
    const y = commit.type === 'milestone' ? 0.9 : commit.type === 'merge' ? 0.3 : 0
    return [weaveX, y, z]
  }, [])

  const currentViewIndex = useMemo(
    () => Math.floor(scrollProgress * (commits.length - 1)),
    [scrollProgress]
  )

  const bloomIntensity = 0.6 + scrollProgress * 0.8

  return (
    <>
      <CameraController scrollProgress={scrollProgress} totalLength={TOTAL_LENGTH} />

      <ambientLight intensity={0.08} color="#0a0d14" />
      <pointLight position={[0, 12, -currentViewIndex * COMMIT_SPACING + 8]} intensity={2.5} color="#3d7fff" distance={40} decay={2} />
      <pointLight position={[14, 2, -currentViewIndex * COMMIT_SPACING - 4]} intensity={1.4} color="#ff5533" distance={30} decay={2} />
      <pointLight position={[-14, -3, -currentViewIndex * COMMIT_SPACING]} intensity={1.0} color="#39d353" distance={28} decay={2} />
      <pointLight position={[0, -10, -currentViewIndex * COMMIT_SPACING - 8]} intensity={0.7} color="#c084fc" distance={25} decay={2} />

      <fog attach="fog" args={['#0D1117', 6, 55]} />

      <Stars radius={200} depth={80} count={3500} factor={6} saturation={0.2} fade speed={0.3} />

      <BackgroundParticles count={500} />

      <mesh ref={gridRef} rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.8, 0]}>
        <planeGeometry args={[120, 200, 60, 100]} />
        <meshBasicMaterial color="#58A6FF" wireframe transparent opacity={0.045} />
      </mesh>

      <TimelineConnections
        commits={commits}
        getCommitPosition={getCommitPosition}
        activeIndex={activeCommitIndex}
      />

      {commits.map((commit, i) => {
        const pos = getCommitPosition(i)
        const dist = Math.abs(i - currentViewIndex)
        const opacity = dist === 0 ? 1 : dist <= 2 ? 0.85 : dist <= 5 ? 0.5 : 0.22
        return (
          <CommitNode
            key={commit.id}
            commit={commit}
            position={pos}
            index={i}
            isActive={i === activeCommitIndex}
            opacity={opacity}
          />
        )
      })}

      <ContributionTerrain
        position={[0, -1, -(commits.length + 3) * COMMIT_SPACING]}
        opacity={scrollProgress > 0.75 ? Math.min(1, (scrollProgress - 0.75) * 4) : 0}
      />

      <EffectComposer multisampling={4}>
        <Bloom
          intensity={bloomIntensity}
          luminanceThreshold={0.12}
          luminanceSmoothing={0.82}
          mipmapBlur
          radius={0.7}
        />
        <ChromaticAberration
          blendFunction={BlendFunction.NORMAL}
          offset={new THREE.Vector2(0.0006, 0.0006)}
          radialModulation
          modulationOffset={0.55}
        />
        <Vignette offset={0.28} darkness={0.75} eskil={false} />
      </EffectComposer>
    </>
  )
}
