'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { GitBranch } from 'lucide-react'
import { branches } from '@/lib/portfolio-data'
import { usePortfolioStore } from '@/lib/store'

export function BranchNavigator() {
  const scrollProgress = usePortfolioStore(s => s.scrollProgress)
  const activeBranch   = usePortfolioStore(s => s.activeBranch)
  const setActiveBranch = usePortfolioStore(s => s.setActiveBranch)
  const show = scrollProgress > 0.1 && scrollProgress < 0.9

  return (
    <AnimatePresence>
      {show && (
        <motion.nav
          initial={{ opacity: 0, x: -16 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -16 }}
          transition={{ duration: 0.35 }}
          className="fixed left-5 top-1/2 -translate-y-1/2 z-30 hidden md:flex flex-col gap-2"
        >
          {/* "Branches" label */}
          <p className="text-[9px] font-mono tracking-widest uppercase mb-1 pl-1" style={{ color: '#555f6a' }}>
            branches
          </p>

          {branches.filter(b => b.name !== 'main').map((branch, i) => {
            const isActive = activeBranch === branch.name
            return (
              <motion.button
                key={branch.name}
                onClick={() => setActiveBranch(isActive ? null : branch.name)}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.07 }}
                className="group flex items-center gap-2.5 rounded-lg text-xs font-mono transition-all text-left overflow-hidden"
                style={{
                  padding: '7px 12px',
                  background: isActive ? `${branch.color}12` : 'rgba(13,17,23,0.7)',
                  border: `1px solid ${isActive ? branch.color + '40' : '#21262D'}`,
                  backdropFilter: 'blur(10px)',
                  boxShadow: isActive ? `0 0 16px ${branch.color}20` : 'none',
                }}
                whileHover={{ x: 3 }}
              >
                {/* Color dot */}
                <div
                  className="w-1.5 h-1.5 rounded-full flex-shrink-0 transition-all"
                  style={{
                    background: branch.color,
                    boxShadow: isActive ? `0 0 8px ${branch.color}` : 'none',
                  }}
                />

                <GitBranch className="w-3 h-3 flex-shrink-0" style={{ color: branch.color, opacity: 0.8 }} />

                <span style={{ color: isActive ? branch.color : '#8B949E' }}>
                  {branch.name}
                </span>

                {/* Skill tags — expand on hover */}
                <div
                  className="flex gap-1 max-w-0 group-hover:max-w-[160px] overflow-hidden transition-all duration-300"
                >
                  {branch.skills.slice(0, 3).map(skill => (
                    <span
                      key={skill}
                      className="text-[9px] px-1.5 py-0.5 rounded flex-shrink-0"
                      style={{
                        background: `${branch.color}12`,
                        color: branch.color,
                        border: `1px solid ${branch.color}25`,
                        letterSpacing: '0.03em',
                      }}
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </motion.button>
            )
          })}
        </motion.nav>
      )}
    </AnimatePresence>
  )
}
