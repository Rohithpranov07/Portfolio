'use client'

import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { contactLinks } from '@/lib/portfolio-data'
import { usePortfolioStore } from '@/lib/store'

interface Line {
  text: string
  type: 'cmd' | 'out' | 'link'
  href?: string
  color?: string
}

const SEQUENCE: Line[] = [
  { text: '$ ls -la',               type: 'cmd' },
  { text: 'total 4 items:',         type: 'out' },
  { text: '  drwxr-xr-x  email.txt  linkedin.md  github.sh  resume.pdf', type: 'out' },
  { text: '',                        type: 'out' },
  ...contactLinks.flatMap(l => [
    { text: `$ ${l.command}`,       type: 'cmd' as const },
    { text: `  ${l.content}`,       type: 'link' as const, href: l.href },
  ]),
  { text: '',                        type: 'out' },
  { text: "$ echo \"Let's build together 🚀\"", type: 'cmd' },
]

export function ContactTerminal() {
  const scrollProgress = usePortfolioStore(s => s.scrollProgress)
  const [lines, setLines]     = useState<Line[]>([])
  const [cursor, setCursor]   = useState(true)
  const [done, setDone]       = useState(false)
  const animated = useRef(false)

  const show = scrollProgress > 0.91

  useEffect(() => {
    const iv = setInterval(() => setCursor(v => !v), 530)
    return () => clearInterval(iv)
  }, [])

  useEffect(() => {
    if (show && !animated.current) {
      animated.current = true
      let idx = 0
      const next = () => {
        if (idx >= SEQUENCE.length) { setDone(true); return }
        const line = SEQUENCE[idx++]
        setLines(prev => [...prev, line])
        setTimeout(next, line.type === 'cmd' ? 480 : 160)
      }
      setTimeout(next, 500)
    }
  }, [show])

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 16 }}
          animate={{ opacity: 1, scale: 1,    y: 0  }}
          exit={{   opacity: 0, scale: 0.96, y: 10  }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="fixed inset-0 z-40 flex items-center justify-center pointer-events-none px-4"
        >
          <div
            className="pointer-events-auto overflow-hidden rounded-xl w-full"
            style={{
              maxWidth: '500px',
              background: '#0D1117',
              border: '1px solid #30363D',
              boxShadow: '0 0 60px rgba(126,231,135,0.12), 0 0 120px rgba(88,166,255,0.06), 0 24px 60px rgba(0,0,0,0.8)',
            }}
          >
            {/* macOS window chrome */}
            <div
              className="flex items-center gap-2 px-4 py-3"
              style={{ background: '#161B22', borderBottom: '1px solid #30363D' }}
            >
              <div className="w-3 h-3 rounded-full" style={{ background: '#ff5f57' }} />
              <div className="w-3 h-3 rounded-full" style={{ background: '#febc2e' }} />
              <div className="w-3 h-3 rounded-full" style={{ background: '#28c840' }} />
              <span className="ml-3 text-[11px] font-mono" style={{ color: '#555f6a' }}>
                dev@portfolio — contact — bash
              </span>
              {/* Glow pulse top right */}
              <div className="ml-auto flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                <span className="text-[9px] font-mono" style={{ color: '#555f6a' }}>connected</span>
              </div>
            </div>

            {/* Terminal body */}
            <div className="p-5 font-mono text-sm min-h-[280px] max-h-[400px] overflow-y-auto space-y-0.5">
              <div className="text-[10px] mb-3" style={{ color: '#555f6a' }}>
                {'// reach out — I respond within 24 hrs'}
              </div>

              {lines.map((line, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.14 }}
                  className="leading-relaxed"
                >
                  {line.type === 'cmd' ? (
                    <span style={{ color: '#7EE787' }}>{line.text}</span>
                  ) : line.type === 'link' && line.href ? (
                    <a
                      href={line.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="transition-colors hover:underline underline-offset-2"
                      style={{ color: '#58A6FF' }}
                    >
                      {line.text}
                    </a>
                  ) : (
                    <span style={{ color: '#555f6a' }}>{line.text}</span>
                  )}
                </motion.div>
              ))}

              {/* Cursor */}
              {!done && (
                <div className="flex items-center gap-1 mt-1">
                  <span style={{ color: '#7EE787' }}>$ </span>
                  <span
                    style={{
                      display: 'inline-block', width: '7px', height: '14px',
                      background: '#7EE787', opacity: cursor ? 1 : 0,
                      transition: 'opacity 0.05s', boxShadow: '0 0 6px #7EE787',
                    }}
                  />
                </div>
              )}

              {done && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  className="mt-3 pt-3 text-[10px]"
                  style={{ borderTop: '1px solid #21262D', color: '#555f6a' }}
                >
                  {"// Thanks for visiting — let's ship something great ✦"}
                </motion.div>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
