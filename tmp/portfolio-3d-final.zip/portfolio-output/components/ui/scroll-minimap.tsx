'use client'

import { motion } from 'framer-motion'
import { commits, branches } from '@/lib/portfolio-data'
import { usePortfolioStore } from '@/lib/store'

export function ScrollMinimap() {
  const scrollProgress     = usePortfolioStore(s => s.scrollProgress)
  const activeCommitIndex  = usePortfolioStore(s => s.activeCommitIndex)

  if (scrollProgress <= 0.02 || scrollProgress >= 0.96) return null

  return (
    <motion.div
      initial={{ opacity: 0, x: 12 }}
      animate={{ opacity: 1, x: 0 }}
      className="fixed right-5 bottom-7 z-30 hidden lg:block"
    >
      <div
        className="rounded-xl px-3 py-3 flex flex-col items-center gap-1"
        style={{
          background: 'rgba(13,17,23,0.82)',
          border: '1px solid #21262D',
          backdropFilter: 'blur(12px)',
          width: '52px',
        }}
      >
        <div className="text-[9px] font-mono mb-1" style={{ color: '#555f6a' }}>
          {Math.round(scrollProgress * 100)}%
        </div>

        {/* Track */}
        <div className="relative flex flex-col items-center gap-[3px]">
          {commits.map((commit, i) => {
            const b = branches.find(b => b.name === commit.branch)
            const isActive = i === activeCommitIndex
            const passed   = i < activeCommitIndex
            const isMile   = commit.type === 'milestone'

            return (
              <div key={commit.id} className="flex items-center justify-center" style={{ width: '28px', height: isMile ? '8px' : '5px' }}>
                <div
                  style={{
                    width:  isActive ? 8 : isMile ? 6 : 4,
                    height: isActive ? 8 : isMile ? 6 : 4,
                    borderRadius: isMile ? '2px' : '50%',
                    background: isActive
                      ? b?.color
                      : passed
                      ? `${b?.color}55`
                      : '#21262D',
                    boxShadow: isActive ? `0 0 8px ${b?.color}` : 'none',
                    transition: 'all 0.25s ease',
                    transform: isActive ? 'rotate(45deg)' : 'none',
                  }}
                />
              </div>
            )
          })}

          {/* Scroll position indicator line */}
          <motion.div
            className="absolute left-0 w-full pointer-events-none"
            style={{
              height: '1px',
              background: 'rgba(88,166,255,0.5)',
              top: `${scrollProgress * 100}%`,
              boxShadow: '0 0 6px #58A6FF',
            }}
          />
        </div>

        <div className="text-[8px] font-mono mt-1 truncate w-full text-center" style={{ color: '#555f6a' }}>
          {commits[activeCommitIndex]?.hash}
        </div>
      </div>
    </motion.div>
  )
}
