'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { GitCommit, Flame, Star, GitMerge, Code2 } from 'lucide-react'
import { stats } from '@/lib/portfolio-data'
import { usePortfolioStore } from '@/lib/store'

export function StatsOverlay() {
  const scrollProgress = usePortfolioStore(s => s.scrollProgress)
  const show = scrollProgress > 0.78

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 14 }}
          transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-30"
        >
          <div
            className="flex items-center gap-0 rounded-xl overflow-hidden"
            style={{
              background: 'rgba(13,17,23,0.9)',
              border: '1px solid #21262D',
              backdropFilter: 'blur(16px)',
              boxShadow: '0 0 40px rgba(88,166,255,0.08)',
            }}
          >
            {[
              { icon: <GitCommit className="w-3.5 h-3.5" />, color: '#58A6FF', value: stats.totalCommits.toLocaleString(), label: 'Commits' },
              { icon: <Flame      className="w-3.5 h-3.5" />, color: '#F05032', value: `${stats.currentStreak}d`,          label: 'Streak'  },
              { icon: <Star       className="w-3.5 h-3.5" />, color: '#e3b341', value: stats.starsEarned,                  label: 'Stars'   },
              { icon: <GitMerge   className="w-3.5 h-3.5" />, color: '#7EE787', value: stats.prsMerged,                    label: 'PRs'     },
              { icon: <Code2      className="w-3.5 h-3.5" />, color: '#D2A8FF', value: '5',                                label: 'Langs'   },
            ].map(({ icon, color, value, label }, i, arr) => (
              <div
                key={label}
                className="flex items-center gap-2.5 px-5 py-3"
                style={{ borderRight: i < arr.length - 1 ? '1px solid #21262D' : 'none' }}
              >
                <span style={{ color }}>{icon}</span>
                <div>
                  <div className="text-sm font-bold font-mono leading-none" style={{ color: '#C9D1D9' }}>{value}</div>
                  <div className="text-[9px] uppercase tracking-widest mt-0.5" style={{ color: '#555f6a' }}>{label}</div>
                </div>
              </div>
            ))}

            {/* Language dots */}
            <div
              className="hidden md:flex items-center gap-2 px-5 py-3"
              style={{ borderLeft: '1px solid #21262D' }}
            >
              {stats.languages.slice(0, 4).map(l => (
                <div key={l.name} className="flex items-center gap-1">
                  <div className="w-1.5 h-1.5 rounded-full" style={{ background: l.color, boxShadow: `0 0 4px ${l.color}` }} />
                  <span className="text-[9px] font-mono" style={{ color: '#555f6a' }}>{l.percentage}%</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
