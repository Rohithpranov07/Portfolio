'use client'

import { useEffect, useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

export function HeroOverlay({ visible }: { visible: boolean }) {
  const [typed, setTyped]     = useState('')
  const [cursor, setCursor]   = useState(true)
  const [phase, setPhase]     = useState(0) // 0=typing, 1=sub, 2=stats, 3=scroll

  const fullText = 'git init developer.portfolio'

  const runTypewriter = useCallback(() => {
    let i = 0
    const iv = setInterval(() => {
      if (i <= fullText.length) {
        setTyped(fullText.slice(0, i++))
      } else {
        clearInterval(iv)
        setTimeout(() => setPhase(1), 300)
        setTimeout(() => setPhase(2), 900)
        setTimeout(() => setPhase(3), 1600)
      }
    }, 52)
    return () => clearInterval(iv)
  }, [])

  useEffect(() => {
    const blink = setInterval(() => setCursor(v => !v), 530)
    return () => clearInterval(blink)
  }, [])

  useEffect(() => {
    if (visible) {
      const t = setTimeout(runTypewriter, 700)
      return () => clearTimeout(t)
    }
  }, [visible, runTypewriter])

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="fixed inset-0 z-20 flex flex-col items-center justify-center pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.5 } }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          {/* Scanline overlay */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.06) 2px, rgba(0,0,0,0.06) 4px)',
            }}
          />

          <div className="text-center px-6 relative">
            {/* "Initialized" line */}
            <motion.p
              className="text-xs tracking-[0.35em] uppercase mb-3 font-mono"
              style={{ color: '#555f6a' }}
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.6 }}
            >
              ▸ Initialized empty Git repository
            </motion.p>

            {/* Giant command prompt */}
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold font-mono tracking-tight leading-none">
              <span style={{ color: '#555f6a' }}>$ </span>
              <span
                style={{
                  color: '#7EE787',
                  textShadow: '0 0 8px #7EE787cc, 0 0 20px #7EE78760',
                }}
              >
                {typed}
              </span>
              <span
                style={{
                  display: 'inline-block',
                  width: '3px',
                  height: '0.85em',
                  background: '#7EE787',
                  marginLeft: '3px',
                  verticalAlign: 'middle',
                  opacity: cursor ? 1 : 0,
                  boxShadow: '0 0 8px #7EE787',
                  transition: 'opacity 0.05s',
                }}
              />
            </h1>

            {/* Subheading */}
            {phase >= 1 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="mt-7"
              >
                <p className="text-base sm:text-lg font-light max-w-xl mx-auto leading-relaxed"
                  style={{ color: '#8B949E' }}>
                  Full-stack developer & creative engineer.
                  Building at the intersection of{' '}
                  <span style={{ color: '#58A6FF', textShadow: '0 0 10px #58A6FF80' }}>frontend craft</span>,{' '}
                  <span style={{ color: '#F05032', textShadow: '0 0 10px #F0503280' }}>systems thinking</span>, and{' '}
                  <span style={{ color: '#7EE787', textShadow: '0 0 10px #7EE78780' }}>AI exploration</span>.
                </p>
              </motion.div>
            )}

            {/* Mini stats row */}
            {phase >= 2 && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="mt-6 flex items-center justify-center gap-6 flex-wrap"
              >
                {[
                  { label: '2847', sub: 'commits' },
                  { label: '16',   sub: 'projects' },
                  { label: '5yr',  sub: 'experience' },
                  { label: '47d',  sub: 'streak' },
                ].map(({ label, sub }) => (
                  <div key={sub} className="flex flex-col items-center">
                    <span className="text-xl font-bold font-mono" style={{ color: '#C9D1D9' }}>{label}</span>
                    <span className="text-[10px] tracking-widest uppercase mt-0.5" style={{ color: '#555f6a' }}>{sub}</span>
                  </div>
                ))}
              </motion.div>
            )}

            {/* Scroll CTA */}
            {phase >= 3 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6 }}
                className="mt-10 flex flex-col items-center gap-2"
              >
                <p className="text-[10px] tracking-[0.3em] uppercase font-mono" style={{ color: '#555f6a' }}>
                  scroll to traverse history
                </p>
                <motion.div
                  animate={{ y: [0, 6, 0] }}
                  transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
                  style={{ color: '#58A6FF' }}
                >
                  ↓
                </motion.div>
              </motion.div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
