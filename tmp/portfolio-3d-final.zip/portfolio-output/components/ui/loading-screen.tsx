'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

interface LoadingScreenProps { onComplete: () => void }

const LINES = [
  { text: '$ git clone https://github.com/dev/portfolio.git', t: 0,    green: true  },
  { text: "Cloning into 'portfolio'...",                       t: 600,  green: false },
  { text: 'remote: Enumerating objects: 2847, done.',          t: 1100, green: false },
  { text: 'remote: Counting objects: 100% (2847/2847), done.', t: 1500, green: false },
  { text: 'remote: Compressing objects: 100%, done.',           t: 1850, green: false },
  { text: 'Receiving objects: 100% (2847/2847), 4.2 MiB.',     t: 2200, green: false },
  { text: 'Resolving deltas: 100% (1523/1523), done.',          t: 2550, green: false },
  { text: '$ cd portfolio && git log --oneline --graph',        t: 3000, green: true  },
]

export function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [visible, setVisible] = useState<number[]>([])
  const [exiting, setExiting] = useState(false)
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    LINES.forEach((l, i) => {
      setTimeout(() => setVisible(v => [...v, i]), l.t)
    })
    const prog = setInterval(() => setProgress(p => Math.min(p + 1.8, 100)), 40)
    setTimeout(() => { setExiting(true); clearInterval(prog) }, 3600)
    setTimeout(onComplete, 4200)
    return () => clearInterval(prog)
  }, [onComplete])

  return (
    <AnimatePresence>
      {!exiting && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ background: '#0D1117' }}
          exit={{ opacity: 0, scale: 1.04, filter: 'blur(8px)' }}
          transition={{ duration: 0.6 }}
        >
          {/* Centered terminal window */}
          <div style={{ width: '480px', maxWidth: '90vw' }}>
            {/* Title bar */}
            <div
              className="flex items-center gap-2 px-4 py-3 rounded-t-xl"
              style={{ background: '#161B22', border: '1px solid #30363D', borderBottom: 'none' }}
            >
              <div className="w-3 h-3 rounded-full" style={{ background: '#ff5f57' }} />
              <div className="w-3 h-3 rounded-full" style={{ background: '#febc2e' }} />
              <div className="w-3 h-3 rounded-full" style={{ background: '#28c840' }} />
              <span className="ml-3 text-[11px] font-mono" style={{ color: '#555f6a' }}>
                bash — portfolio — 80×24
              </span>
            </div>

            {/* Terminal body */}
            <div
              className="rounded-b-xl px-5 py-4 font-mono text-[12px] min-h-[200px]"
              style={{
                background: '#0D1117',
                border: '1px solid #30363D',
                boxShadow: '0 0 60px rgba(88,166,255,0.08), 0 20px 60px rgba(0,0,0,0.7)',
              }}
            >
              {LINES.map((line, i) => (
                visible.includes(i) && (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.18 }}
                    className="leading-loose"
                    style={{ color: line.green ? '#7EE787' : '#8B949E' }}
                  >
                    {line.text}
                  </motion.div>
                )
              ))}
              {visible.length < LINES.length && (
                <span
                  className="inline-block w-[7px] h-[13px] ml-0.5"
                  style={{ background: '#7EE787', animation: 'blink 1s step-end infinite' }}
                />
              )}
            </div>

            {/* Progress bar */}
            <div className="mt-4 h-[2px] w-full rounded-full overflow-hidden" style={{ background: '#21262D' }}>
              <motion.div
                className="h-full rounded-full"
                style={{
                  width: `${progress}%`,
                  background: 'linear-gradient(90deg, #58A6FF, #7EE787)',
                  boxShadow: '0 0 8px #58A6FF80',
                  transition: 'width 0.04s linear',
                }}
              />
            </div>
            <p className="text-center font-mono text-[10px] mt-2" style={{ color: '#555f6a' }}>
              Loading 3D environment… {Math.round(progress)}%
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
