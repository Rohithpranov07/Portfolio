'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { GitBranch, ExternalLink, Github, GitCommit, Plus, Minus } from 'lucide-react'
import { commits, branches } from '@/lib/portfolio-data'
import { usePortfolioStore } from '@/lib/store'

export function CommitDetailPanel() {
  const activeCommitIndex = usePortfolioStore((s) => s.activeCommitIndex)
  const scrollProgress     = usePortfolioStore((s) => s.scrollProgress)

  const commit = commits[activeCommitIndex]
  const branch = branches.find(b => b.name === commit?.branch)
  const show   = scrollProgress > 0.05 && !!commit?.project

  if (!show || !commit?.project || !branch) return null

  const addPct = Math.round(commit.project.additions / (commit.project.additions + commit.project.deletions + 1) * 100)

  return (
    <AnimatePresence mode="wait">
      <motion.aside
        key={commit.id}
        initial={{ opacity: 0, x: 28, filter: 'blur(6px)' }}
        animate={{ opacity: 1, x: 0,  filter: 'blur(0px)' }}
        exit={{   opacity: 0, x: 28,  filter: 'blur(4px)' }}
        transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
        className="fixed right-5 top-1/2 -translate-y-1/2 z-30 hidden lg:flex flex-col gap-0"
        style={{ width: '290px' }}
      >
        {/* ── Top accent bar */}
        <div
          className="h-[3px] w-full rounded-t-xl"
          style={{ background: `linear-gradient(90deg, ${branch.color}00, ${branch.color}, ${branch.color}00)` }}
        />

        <div
          className="rounded-b-xl overflow-hidden"
          style={{
            background: 'rgba(13,17,23,0.88)',
            backdropFilter: 'blur(18px)',
            border: `1px solid ${branch.color}20`,
            borderTop: 'none',
            boxShadow: `0 0 40px ${branch.color}18, inset 0 0 40px rgba(0,0,0,0.4)`,
          }}
        >
          {/* Branch + hash header */}
          <div className="flex items-center gap-2 px-4 py-3" style={{ borderBottom: '1px solid #21262D' }}>
            <GitBranch className="w-3 h-3 flex-shrink-0" style={{ color: branch.color }} />
            <span className="text-xs font-mono font-medium" style={{ color: branch.color }}>{commit.branch}</span>
            <span className="text-xs font-mono ml-1" style={{ color: '#555f6a' }}>{commit.hash}</span>
            {commit.tag && (
              <span
                className="ml-auto text-[10px] font-mono px-2 py-0.5 rounded"
                style={{
                  background: `${branch.color}18`,
                  color: branch.color,
                  border: `1px solid ${branch.color}35`,
                  boxShadow: `0 0 8px ${branch.color}30`,
                }}
              >
                {commit.tag}
              </span>
            )}
          </div>

          <div className="px-4 pt-3 pb-4">
            {/* Commit message */}
            <p className="text-[11px] font-mono mb-3 leading-relaxed" style={{ color: '#555f6a' }}>
              {commit.message}
            </p>

            {/* Project title */}
            <h3
              className="text-lg font-bold font-mono mb-1 leading-tight"
              style={{ color: branch.color, textShadow: `0 0 18px ${branch.color}50` }}
            >
              {commit.project.title}
            </h3>

            <p className="text-xs leading-relaxed mb-4" style={{ color: '#8B949E' }}>
              {commit.project.description}
            </p>

            {/* Tech chips */}
            <div className="flex flex-wrap gap-1.5 mb-4">
              {commit.project.tech.map(t => (
                <span
                  key={t}
                  className="text-[10px] px-2 py-0.5 rounded font-mono"
                  style={{ background: '#0D1117', color: '#8B949E', border: '1px solid #30363D' }}
                >
                  {t}
                </span>
              ))}
            </div>

            {/* Diff stats bar */}
            <div className="flex items-center gap-2 mb-4">
              <span className="text-[11px] font-mono flex items-center gap-1" style={{ color: '#7EE787' }}>
                <Plus className="w-2.5 h-2.5" />{commit.project.additions.toLocaleString()}
              </span>
              <span className="text-[11px] font-mono flex items-center gap-1" style={{ color: '#f85149' }}>
                <Minus className="w-2.5 h-2.5" />{commit.project.deletions.toLocaleString()}
              </span>
              <div className="flex-1 h-1 rounded-full overflow-hidden ml-1" style={{ background: '#21262D' }}>
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${addPct}%`,
                    background: `linear-gradient(90deg, #7EE787, ${branch.color})`,
                    boxShadow: `0 0 6px ${branch.color}60`,
                  }}
                />
              </div>
            </div>

            {/* Links */}
            <div className="flex gap-2">
              {commit.project.link && (
                <a
                  href={commit.project.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-[11px] px-3 py-1.5 rounded-md font-mono transition-all hover:scale-105"
                  style={{
                    background: `${branch.color}14`,
                    color: branch.color,
                    border: `1px solid ${branch.color}30`,
                  }}
                >
                  <ExternalLink className="w-2.5 h-2.5" />Live
                </a>
              )}
              {commit.project.github && (
                <a
                  href={commit.project.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-[11px] px-3 py-1.5 rounded-md font-mono transition-all hover:opacity-80"
                  style={{ background: '#161B22', color: '#8B949E', border: '1px solid #30363D' }}
                >
                  <Github className="w-2.5 h-2.5" />Source
                </a>
              )}
            </div>

            {/* Date */}
            <p className="mt-3 pt-3 text-[10px] font-mono flex items-center gap-1.5"
              style={{ color: '#555f6a', borderTop: '1px solid #21262D' }}>
              <GitCommit className="w-2.5 h-2.5" />
              {new Date(commit.date).toLocaleDateString('en-US', { year:'numeric', month:'long', day:'numeric' })}
            </p>
          </div>
        </div>
      </motion.aside>
    </AnimatePresence>
  )
}
